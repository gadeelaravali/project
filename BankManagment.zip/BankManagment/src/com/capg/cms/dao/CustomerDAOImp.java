package com.capg.cms.dao;
import java.util.HashMap;
import java.util.Iterator;
/*import java.util.List;
import java.util.ArrayList;*/
import java.util.Map;
import java.util.Set;

import com.capg.cms.beans.Customer;
public class CustomerDAOImp implements ICustomerDAO {
	Map<Integer,Customer> custList=new HashMap<Integer,Customer>();		
	Map<Integer,StringBuffer> transaction=new HashMap<Integer,StringBuffer>();
	//Customer a=new Customer(null,null,0,null,0,null);
	//static List<Customer> custList = new ArrayList<Customer>();
	@Override
	public boolean addCustomer(Customer c) {
	int key=c.getAccno();
	custList.put(key,c);
	return custList.containsValue(c);	
	}
	@Override
	public boolean validateAccno(int id1) {
	boolean flag=false;
		for (Customer c:custList.values()) {
			if((c.getAccno()==id1))
	//	if(ca.getAccno()==accno)
		flag=true;
		}
		return flag;
	}
	@Override
	public boolean validatePinno(int id2) {
	boolean flag=false;
		for (Customer c:custList.values()) {
			if((c.getPin()==id2))
	//	if(ca.getAccno()==accno)
		flag=true;
		}
		return flag;
	}
	
	public Customer displayCustomer(int id1,int id2) {	
	Customer cust=null;
	for(Customer c:custList.values())
	{
		if((c.getAccno()==id1)&&(c.getPin()==id2))
		{
		System.out.println("Balance is:"+c.getAmt());	
		}
	}
	return cust;
	}
	public Customer withDraw(int accno,int pinno,int wd) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for(Customer c:custList.values())
		{			
		if((c.getAmt()>wd))
		{
		int bal=0;
		bal=c.getAmt()-wd;
		c.setAmt(bal);
		System.out.println("balance is"+c.getAmt());
		}
		}			
		return cust;
	}
	public int depositAmt(int da,Customer c) {
		// TODO Auto-generated method stub		
		int bal=0;
		bal=c.getAmt()+da;          
		c.setAmt(bal);
		System.out.println("balance is"+c.getAmt());
		System.out.println("deposit done successfully");			
		return c.getAmt();
	}
	@Override
	public Customer printTransactions(int cid,int pinno) {
		// TODO Auto-generated method stub
	for(StringBuffer trans:transaction.values())
	{
		if(transaction.containsKey(cid))
	{
		System.out.println("sssss");
		System.out.println(transaction.values());
	}
	}
		return null;
	}
	

	public Customer printTransactions(Customer cid) {
		// TODO Auto-generated method stub
		Customer cust=null;
		int acc=cid.getAccno();
		StringBuffer s= new StringBuffer();
		s=cid.getSb();	
		s.append(cid.getAmt());
		cid.setSb(s);
		transaction.put(acc,s);
		for(StringBuffer transaction1:transaction.values())
		{System.out.println("sssss");
		transaction.entrySet().stream().forEach(System.out::println);	
		System.out.println("transaction");
		}
		
		return cust;
	}
	

	public Customer displayCust(int accno) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for (Customer c:custList.values()) {
			if(c.getAccno()==accno)
					{
				cust=c;
					}
		}return cust;
	}
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno)
	{
		boolean flag=false;	
			if((c.getAccno()==accno1) && (c.getPin()==pinno))
			{
				if(b.getAccno()==accno2)
				{
					if((c.getAmt()>amt))
					{
					int bal=0;
					int bal1=0;
					bal=c.getAmt()-amt;
					bal1=b.getAmt()+amt;
					c.setAmt(bal);
					b.setAmt(bal1);
					flag=true;
					}
				}
			
		}
	return flag;
}
}

